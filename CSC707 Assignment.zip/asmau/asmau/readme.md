Name: Asmau Zailani Ahmad
Adm. No:2200244003
****************************************************
Why I designed it like that
****************************************************
1. For userability and eccessibility, i added useful links in the footer after placing the navigation bar at the top
2. For Uniformity I maintained thesame color, font type and font size for all the pages 
3. For responsiveness i decided to use Bootstrap frame work

*****************************************************
Challenges
*****************************************************
1. It took me time to start due to the fact that I have to learn bootstrap technology from scratch
2. I face so many hoodles because it has been so long that i work with html and css
3. It took alot of time in the process too
