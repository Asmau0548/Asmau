Name: 
Adm. No:
****************************************************
Why I designed it like that
****************************************************
1. For userability and eccessibility i decided to after placing the navigation bar at the top I also add useful links in the footer
2. For Uniformity I maintain the same color, font type and font size for all the pages 
3. For responsiveness i decided to use Bootstrap frame work

*****************************************************
Challenges
*****************************************************
1. It took me time start due to the fact that I have to learn bootstrap technology from scratch
2. I face so many hoodles because it has been so long when i work with html and css
